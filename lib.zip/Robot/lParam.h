#ifndef __LPARAM_H__
#define __LPARAM_H__
#include "dhMat.h"
class Joint6{
public:
    Joint6();
    ~Joint6();
public:
    float q1,q2,q3,q4,q5,q6;
    Joint6 RAD();
    Joint6 DEG();
};
#endif