#include "pch.h"
#include "lObj.h"

lObj::lObj()
{
	Initialzation();
}

lObj::~lObj()
{
	GLDelete();
	Close();
}

void lObj::Initialzation()
{
	pVt = NULL;
	vtn = 0;
	pPl = NULL;
	pln = 0;
	VAO = 0;
	VBO = 0;
	EBO = 0;
}

void lObj::Init(int v, int p)
{
	Close();
	pVt = new dhVertex[v];
	vtn = v;
	pPl = new lPoly[p];
	pln = p;
}

void lObj::Close()
{
	if (pVt)delete[](pVt);
	if (pPl)delete[](pPl);
	pVt = NULL;
	pPl = NULL;
	vtn = 0;
	pln = 0;

	GLDelete();
}

void lObj::GLDelete()
{
	if(VAO)glDeleteVertexArrays(1, &VAO);
	if (VBO)glDeleteBuffers(1, &VBO);
	if (EBO)glDeleteBuffers(1, &EBO);
	VAO = 0;
	VBO = 0;
	EBO = 0;
}

void lObj::GLSet()
{
	if (pVt == NULL || pPl == NULL)return;
	Check = true;
	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO);
	glGenBuffers(1, &EBO);

	glBindVertexArray(VAO);

	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(dhVertex)*vtn, pVt, GL_STATIC_DRAW);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(lPoly)*this->pln, pPl , GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (GLvoid*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	glBindVertexArray(0);
}

void lObj::Triangle()
{
	int i;
	Init(3, 1);
	pVt[0].SetPoint(0, 0, 0);
	pVt[1].SetPoint(1, 0, 0);
	pVt[2].SetPoint(0, 1, 0);
	for (i = 0; i < 3; i++)
		pVt[i].SetNomalVector(0, 0, 1);
	pPl[0].SetPoly(0, 1, 2);
	GLSet();
	Close();
}

void lObj::Box(float x, float y, float z)
{
	int i;
	Init(8,12);
	pVt[0].SetPoint(0, 0, 0);
	pVt[1].SetPoint(x, 0, 0);
	pVt[2].SetPoint(x, y, 0);
	pVt[3].SetPoint(0, y, 0);
	pVt[4].SetPoint(0, 0, z);
	pVt[5].SetPoint(x, 0, z);
	pVt[6].SetPoint(x, y, z);
	pVt[7].SetPoint(0, y, z);
	for (i = 0; i < 8; i++) 
		pVt[i].SetNomalVector(0, 0, 1);
	pPl[0].SetPoly(0, 3, 2);
	pPl[1].SetPoly(0, 2, 1);
	pPl[2].SetPoly(0, 7, 3);
	pPl[3].SetPoly(0, 4, 7);
	pPl[4].SetPoly(0, 1, 5);
	pPl[5].SetPoly(0, 5, 4);
	pPl[6].SetPoly(6, 7, 4);
	pPl[7].SetPoly(6, 4, 5);
	pPl[8].SetPoly(6, 2, 1);
	pPl[9].SetPoly(6, 1, 5);
	pPl[10].SetPoly(6, 3, 7);
	pPl[11].SetPoly(6, 2, 3);
	GLSet();
	Close();


}

void lObj::Cylinder(float, float)
{
}

void lObj::Draw()
{ 
	glBindVertexArray(VAO);
    glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, 0);
    glBindVertexArray(0);
}

void lObj::ShaderSet(const char* vs, const char*fs)
{
	vShader.Read(vs);
	fShader.Read(fs);
}
