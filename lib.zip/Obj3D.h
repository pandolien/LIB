#ifndef __OBJ3D_H__
#define __OBJ3D_H__
#include "lPTRList.h"
#include "lString.h"
#include "3d/dhMat.h"
#include "lObj.h"



class Obj3D
{
public:
	Obj3D();
	~Obj3D();
public:
	lPTRList list;
	lPTRList ltName;
public:
	void Delete();
	void SetData(lString sdrVt, lString sdrFr,void* Cam,void* light);
	void Draw();
	void Read(lString);
};

#endif