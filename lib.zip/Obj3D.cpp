#include "pch.h"
#include "Obj3D.h"
#include "lToken.h"
#include "3d/dhVertex.h"
#include "lPoly.h"
Obj3D::Obj3D()
{
}

Obj3D::~Obj3D()
{
	
}

void Obj3D::Delete()
{
	int i;
	if (list.GetSize() > 0) {
		for (i = 0; i < list.GetSize(); i++) {
			lObj* obj = (lObj*)list.Search(i);
			obj->GLDelete();
		}
		list.RemoveAll();
	}
	if (ltName.GetSize() > 0) {
		for (i = 0; i < ltName.GetSize(); i++) {
			lString* str = (lString*)ltName.Search(i);
			str->Delete();
		}
		ltName.RemoveAll();
	}

}

void Obj3D::SetData(lString sdrVt, lString sdrFr, void* Cam, void* light)
{
	int i;
	for (i = 0; i < list.GetSize(); i++) {
		lObj* obj = (lObj*)list.Search(i);
		obj->SetCam(Cam);
		obj->SetLight(light);
		obj->SetColor(0, 255, 0, 255);
		obj->SetShader(sdrVt.GetC(),sdrFr.GetC());
	}
}

void Obj3D::Draw()
{
	int i;
	for (i = 0; i < list.GetSize(); i++) {
		lObj* obj = (lObj*)list.Search(i);
		obj->Draw();
	}
}

void Obj3D::Read(lString name)
{
	unsigned short ID,num;
	unsigned int ByteSize;
	int i;
	int vtn, pln;
	dhVertex* pVt;
	lPoly *pPl;
	lString str;
	lToken tok;
	FILE* fd;
	lObj* Obj= NULL;
	Delete();
	tok.Split(name, ".");
	str = tok.Search(1);
	if (str != "3ds") return;
	fd = fopen(name.GetC(), "rb");
	fread(&ID, 2, 1, fd);
	fread(&ByteSize, 4, 1, fd);
	if (ID != 0x4D4D) {
		return;
	}
	while (!feof(fd)) {
		fread(&ID, 2, 1, fd);
		fread(&ByteSize, 4, 1, fd);
		if (ID == 0x3D3D) {
		
		}
		else if (ID == 0x4000) {
			char n[20] = { 0, };
			//lString* p = new lString();
			
			//Obj = new lObj();
			//p->Initialzation();
			for (i = 0; i < 20; i++) {
				fread(&n[i], 1, 1, fd);
				if (n[i] == '\0')break;
			}
			//*p = n;
			//list.AddTail(Obj);
			//ltName.AddTail(p);
		}
		else if (ID == 0x4100);
		else if (ID == 0x4110) {
			float x, y, z;
			fread(&num, sizeof(unsigned short), 1, fd);
			pVt = new dhVertex[num];
			vtn = num;
			for (i = 0; i < num; i++) {
				fread(&x, sizeof(float), 1, fd);
				fread(&y, sizeof(float), 1, fd);
				fread(&z, sizeof(float), 1, fd);
				//pVt[i].SetPoint(x, y, z);
			}
		}
		else if (ID == 0x4120) {
			fread(&num, sizeof(unsigned short), 1, fd);
			pPl = new lPoly[num];
			pln = num;
			for (i = 0; i < num; i++) {
				short a, b, c;
				//fread(&pPl[i], sizeof(lPoly), 1, fd);
				fread(&a, 2, 1, fd);
				fread(&b, 2, 1, fd);
				fread(&c, 2, 1, fd);
				fseek(fd, 2, SEEK_CUR);
			}
		}
		else if (ID == 0x4160) {
			fseek(fd, ByteSize - 6, SEEK_CUR);
		}
		else {
			fseek(fd, ByteSize - 6, SEEK_CUR);
		}
	}
	Obj->SetNorm(pVt, vtn, pPl, pln);
	Obj->SetGLBuffer(pVt, vtn, pPl, pln);
	delete[](pVt);
	delete[](pPl);
	tok.Delete();
	str.Delete();

}
