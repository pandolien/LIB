#ifndef __LOBJECT_H__
#define __LOBJECT_H__
#include <GL/glew.h>
#include <GL/GL.h>
#include <GL/GLU.h>

#include "3d/dhVertex.h"
#include "3d/dhMat.h"
#include "lPoly.h"
#include "lRGB.h"
class lObj
{
public:
	lObj();
	~lObj();
public:
	void Initialzation();
	void GLDelete();
	void SetCam(void* c);
	void SetLight(void* l);
	BOOL SetShader(const char*, const char*);
	void SetColor(BYTE, BYTE, BYTE, BYTE);
	void SetOptical(float, float, float);
private://Object Moving And Camera Moveing
	void *c,*L;
	dhMat h, s;
	lRGB lColor;
	float Ambient, Diffuse, Specular;
	int vtn, pln;
	unsigned int VBO, VAO, EBO;
	unsigned int sdrProgram;
private://OpenGL Setting
	void SetGLBuffer(dhVertex*, int, lPoly*, int);
	void SetNorm(dhVertex*, int, lPoly*, int);
public:
	void Triangle();
	void Floor(float, float);
	void Box(float, float, float);
	void Cylinder(float, float);
public://Out Setting
	void Draw();
	void T(dhMat h);
public:
	float* GetColor();
	float GetAmbient();
	float GetDiffuse();
	float GetSpecular();
	
};
#endif;
