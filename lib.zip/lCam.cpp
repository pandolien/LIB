#include "pch.h"
#include "lCam.h"

lCam::lCam()
{
	Initialzation();
}

lCam::~lCam()
{
}

void lCam::Initialzation()
{
	int n, f;
	n = 1;
	f = 65535;
	Projection.v[10] = (n + f )/ (n - f);
	Projection.v[11] = -1;
	Projection.v[14] = 2*n*f/(n-f);
	Projection.v[15] = 0;

}

void lCam::SETAspectRatioAndFOV(float a, float w, float h)
{
	float a_ = a / 2;
	float cot = cos(a_) / sin(a_);
	float ratio = w / h;
	Projection.v[0] = cot / ratio;
	Projection.v[5] = cot ;
}

void lCam::T(dhMat h)
{
	Cam = h;
}
