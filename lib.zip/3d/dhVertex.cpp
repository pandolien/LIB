#include "pch.h"
#include "3d/dhVertex.h"

dhVertex::dhVertex()
{
	Initialzation();
}

dhVertex::~dhVertex()
{
	Close();
}

void dhVertex::Initialzation()
{
	x = 0; y = 0; z = 0;
	nx = 0; ny = 0; nz = 0;
}

void dhVertex::Close()
{
	x = 0; y = 0; z = 0;
	nx = 0; ny = 0; nz = 0;
}

void dhVertex::SetPoint(float x, float y, float z)
{
	this->x = x;
	this->y = y;
	this->z = z;
}

void dhVertex::SetNomalVector(float nx, float ny, float nz)
{
	this->nx = nx;
	this->ny = ny;
	this->nz = nz;
}

dhVector dhVertex::GetPoint()
{
	dhVector v = dhVector(x, y, z);
	return v;
}
