#ifndef __LOBJECT_H__
#define __LOBJECT_H__
#include <GL/glew.h>
#include <GL/GL.h>
#include <GL/GLU.h>
#include "3d/dhVertex.h"
#include "lPoly.h"
#include "lString.h"
class lObj
{
public:
	lObj();
	~lObj();
public:
	void Initialzation();
	void Init(int, int);
	void Close();
	void GLDelete();
private:
	lString vShader,fShader;
	BOOL Check;
	dhVertex *pVt;
	int vtn;
	lPoly* pPl;
	int pln;
	unsigned int VBO, VAO, EBO;
private:
	void GLSet();
public:
	void Triangle();
	void Box(float, float, float);
	void Cylinder(float, float);
public:
	void Draw();
	void ShaderSet(const char*,const char*);
};
#endif;
