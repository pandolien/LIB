
#include "pch.h"
#include "lString.h"

lString::lString()
{
	Initialzation();
}

lString::lString(const char str)
{
	Initialzation();
	Init(str);
}

lString::lString(const char* str)
{
	Initialzation();
	Init(str);
}

#ifdef _WIN64 
lString::lString(LPCTSTR lpctstr)
{
	n = WideCharToMultiByte(CP_ACP, 0, lpctstr, -1, nullptr, 0, nullptr, nullptr);
	str = new char[n + 1];
	memset(str, 0, n+1);
	WideCharToMultiByte(CP_ACP, 0, lpctstr, -1, str, n, NULL, NULL);
}
#elif _WIN32

lString::lString(LPCTSTR lpctstr)
{
	n = WideCharToMultiByte(CP_ACP, 0, lpctstr, -1, nullptr, 0, nullptr, nullptr);
	str = new char[n + 1];
	memset(str, 0, n + 1);
	WideCharToMultiByte(CP_ACP, 0, lpctstr, -1, str, n, NULL, NULL);
}
#endif
lString::lString(lString& str)
{
	Initialzation();
	Init((const lString&)str);
	str.TempRemove();
}

lString::lString(const lString& str)
{
	Initialzation(); 
	Init(str);
}

lString::~lString()
{
	if (isTemp())return;
	Delete();
}

void lString::Initialzation()
{
	NoTemp();
	str = NULL;
	n = 0;
}

void lString::Init(const char str)
{
	Delete();
	this->str = new char[2];
	memset(this->str, 0, 2);
	this->str[0] = str;
}

void lString::Init(const char* str)
{
	int len;
	if (str == NULL)return;
	Delete();
	len = strlen(str);
	this->str = new char[len + 1];
	n = len;
	memset(this->str, 0, n+1);
	memmove(this->str, str, len);
}
void lString::Init(const lString& str)
{
	Delete();
	if (str.str == NULL)return;
	if (str.temp) {
		this->str = str.str;
		n = str.n;
		Temp();
	}
	else {
		this->str = new char[str.n + 1];
		memset(this->str, 0, str.n + 1);
		memmove(this->str, str.str, str.n);
		n = str.n;
		NoTemp();
	}
}

void lString::Format(const char*format, ...)
{
	va_list args;
	int n;
	char buf[1024];
	va_start(args, format);
	vsnprintf(buf, 1024, format, args);
	Init(buf);
	va_end(args);
}

void lString::Delete()
{
	if (str)delete[](str);
	str = NULL;
}

void lString::Read(const char* name)
{
	FILE* fp = NULL;
	long size;
	fp = fopen(name, "rb");
	if (fp == NULL) { return; }
	Delete();
	fseek(fp, 0, SEEK_END);
	size = ftell(fp);   
	fseek(fp, 0,SEEK_SET);
	str = new char[size+1];
	memset(str, 0, size + 1);
	this->n = size;
	fread(str, 1, size,fp);
	fclose(fp);
}

char* lString::GetC()
{
	NoTemp();
	return str;
}

long lString::GetLen()
{
	NoTemp();
	return n;
}

bool lString::In(lString str)
{
	char* p = strstr(GetC(), str.GetC());
	NoTemp();
	str.NoTemp();
	if(p)return true;
	return false;
}

lString lString::operator+(lString str)
{
	lString out;
	out.str = new char[n + str.GetLen()+1];
	out.n = n + str.GetLen();
	memset(out.str, 0, out.n+1);
	memmove(&out.str[0], this->str, n);
	memmove(&out.str[n], str.str, str.n);
	out.Temp();
	NoTemp();
	return out;
}

void lString::operator=(lString str)
{
	Delete();
	if (str.GetC() != NULL) {
		this->str = new char[str.GetLen() + 1];
		n = str.GetLen();
		memset(this->str, 0, str.GetLen() + 1);
		memmove(this->str, str.GetC(), str.GetLen());
	}
	str.TempRemove();
	NoTemp();
}

bool lString::operator==(lString str)
{
	int dt;
	if (str.str == NULL)return false;
	dt = strcmp(this->str, str.str);
	NoTemp();
	str.NoTemp();
	if (dt == 0)return true;
	return false;
}

bool lString::operator==(char* str)
{
	int dt = strcmp(this->str, str);
	NoTemp();
	if (dt == 0)return true;
	return false;
}

bool lString::operator!=(lString str)
{
	int dt = strcmp(this->str, str.str);
	NoTemp();
	str.NoTemp();
	if (dt == 0)return false;
	return true;
}

int lString::Int()
{
	NoTemp();
	return atoi(str);
}

float lString::Float()
{
	NoTemp();
	return atof(str);
}
