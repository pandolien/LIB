#ifndef __GLGRAPH_H__
#define __GLGRAPH_H__
#include "MFC/lOpenGL.h"
#include "lObj.h"
class glGraph : public lOpenGL{
public:
	glGraph();
	~glGraph();
public:
	lObj obj,floor,box;
	float angle;
private:
	void GLObjectCreate();
	void GLRenderScene();
	void GLObjectDelete();
};
#endif
